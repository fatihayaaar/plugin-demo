package com.fayardev.plugindemo.plugin.adapter;

public interface UserPluginAdapter {

    boolean confirm(String username, String password);
}
