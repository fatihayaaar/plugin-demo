package com.fayardev.plugindemo.plugin.adapter;

public interface UserPluginAdapter {

    String confirm(String username, String password);
}
