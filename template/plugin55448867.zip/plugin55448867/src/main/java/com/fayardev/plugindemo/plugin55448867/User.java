package com.fayardev.plugindemo.plugin55448867;

import com.fayardev.plugindemo.plugin.adapter.UserPluginAdapter;

public class User implements UserPluginAdapter {
    @Override
    public String confirm(String username, String password) {
        return null;
    }
}
